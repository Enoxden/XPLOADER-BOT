<h1 align="center"> 𝐗𝐏𝐋𝐎𝐀𝐃𝐄𝐑 𝐁𝐎𝐓 </h1>
<h1 align="center"> 𝖵𝖤𝖱𝖲𝖨𝖮𝖭 3.3.5 </h1>

<p align="center">
  <a href="https://github.com/Dark-Xploit/XPLOADER-BOT">
    <img alt="xploader docs" height="400" src="https://i.ibb.co/DRW8wCV/Xploader4.jpg">
  </a>
</p>
    
   
  
</a>
</p>
<p align="center">
<a href="https://github.com/Dark-Xploit"><img title="Author" src="https://img.shields.io/badge/XPLOADER-BOT-skyblue?style=for-the-badge&logo=telegram"></a>
<p/>
<p align="center">
<a href="https://github.com/Dark-Xploit/XPLOADER-BOT/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Dark-Xploit/XPLOADER-BOT?&style=social"></a>
<a href="https://github.com/Dark-Xploit/XPLOADER-BOT/network/members"><img title="Fork" src="https://img.shields.io/github/forks/Dark-Xploit/XPLOADER-BOT?style=social"></a>
<a href="https://github.com/Dark-Xploit/XPLOADER-BOT/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Dark-Xploit/XPLOADER-BOT?label=Watching&style=social"></a>
</p>
<p align="center"><img src="https://profile-counter.glitch.me/{Dark-Xploit}/count.svg" alt="XPLOADER-BOT:: Visitor's Count" /></p>


<h3>XPLOADER STATS</h3>

<p align="center">
<a href="https://github.com/Dark-Xploit/XPLOADER-BOT/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Dark-Xploit/XPLOADER-BOT?color=orange&style=flat-square"></a>
<a href="https://github.com/Dark-Xploit/XPLOADER-BOT/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Dark-Xploit/XPLOADER-BOT?color=orange&style=flat-square"></a>
<a href="https://github.com/Dark-Xploit/XPLOADER-BOT/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Dark-Xploit/XPLOADER-BOT?label=Watchers&color=orange&style=flat-square"></a>
<a href="https://github.com/Dark-Xploit/XPLOADER-BOT"><img title="Open Source" src="https://img.shields.io/badge/Author-Tylor-orange?v=103"></a>
<a href="https://github.com/Dark-Xploit/XPLOADER-BOT/"><img title="Size" src="https://img.shields.io/github/repo-size/Dark-Xploit/XPLOADER-BOT?style=flat-square&color=orange"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FDark-Xploit%2FXPLOADER-BOT&count_bg=%23FFA500&title_bg=%23555555&icon=probot.svg&icon_color=%23FFA500&title=hits&edge_flat=false"/></a>
<a href="https://github.com/Dark-Xploit/XPLOADER-BOT/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-Yes-orange.svg"></a>&nbsp;&nbsp;
</p>
<p align='center'>
</p>

  
## 🛠️ `XPLOADER INSTALATION`
1. Fork and star this repo first
    <br>
    <p align="center">
<a href='https://github.com/Dark-Xploit/XPLOADER-BOT/fork' target="_blank"><img alt='Fork Repo' src='https://img.shields.io/badge/Fork Repo-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=orange&color=darkgreen'/></a>

2. GET SESSION
    <br>
    <p align="center">
<a href='https://xploaderbots.us.kg/' target="_blank"><img alt='REQUEST PAIR CODE' src='https://img.shields.io/badge/Pair_code-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkorange&color=darkorange'/></a>


## `DEPLOYMENTS`
  
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://xploaderbots.us.kg/deploy)  
💯 safe
    

[![Deploy on Repl.it](https://repl.it/badge/github/quiec/whatsAlfa)](https://repl.it/github/Dark-Xploit/XPLOADER-BOT)


<p align="left">
    <a href="https://app.koyeb.com/apps/deploy?type=git&repository=github.com%2FDark-Xploit%2FXPLOADER-BOT&branch=main&name=XPLOADER-BOT&builder=dockerfile&env[DATABASE_URL]=&env[SESSION_ID]=Enter+your+session+id+here&env[AUTO_STATUS_SEEN]=true&env=[AUTO_REACT_STATUS]=true&env[OWNER_NUMBER]=Enter+your+number&env[OWNER_NAME]=Enter+your+name&env[TIMEZONE]=Africa/Nairobi">
        <img src="https://www.koyeb.com/static/images/deploy/button.svg" height="40"/>
    </a>
</p>



<details>
<summary>𝘋𝘌𝘗𝘓𝘖𝘠 𝘛𝘖 𝘏𝘌𝘙𝘖𝘒𝘜, 𝘔𝘌𝘛𝘏𝘖𝘋 2</summary>
 
* `Fork` Xploader Repository or `sync` if you had forked.
* `Link` to your WhatsApp using Server 1, 2 or 3
* Incase you use Server 3, paste the session id on settings.js @SESSION_ID
* If you used Server 2, upload the `creds.json` received in the `session` folder.
* Alternatively; you can open the `creds.json` using `Mt manager` or `treb edit` and copy everything and paste at `creds.json` on the `session` folder.
* Go to `src>data>role>owner.json` and enter your number.
* Edit your details at `settings.js` (Optional).
* Create an `heroku` account if you don't have.
* Then choose create new app
* Enter your app name and Create.
* Connect with your GitHub account.
* Search Xploader-bot, and connect.
* Press deploy and wait for a few minutes.
* Enjoy.
</details>

<details>
<summary>𝘔𝘖𝘙𝘌 𝘋𝘌𝘗𝘓𝘖𝘠𝘔𝘌𝘕𝘛𝘚</summary>
 
<p align="center">
  <a href="https://dashboard.render.com/select-repo?type=web"><img src="https://img.shields.io/badge/render-333333?style=for-the-badge&logo=render&logoColor=FFFFFF"></a>
  <p align="center">
  <a href="https://account.solarhosting.cc/register?ref=6JR38R0T"><img src="https://img.shields.io/badge/solar hosting-000000?style=for-the-badge&logo=solar hosting&logoColor=FFA500"></a>
 <p align="center">
  <a href="https://bot-hosting.net/?aff=1230335382248488971"><img src="https://img.shields.io/badge/bot hosting-000000?style=for-the-badge&logo=bot hosting &logoColor=FFA500"></a>
</details>


<details>
<summary>𝘏𝘖𝘞 𝘛𝘖 𝘋𝘌𝘗𝘓𝘖𝘠 𝘖𝘕 𝘗𝘈𝘕𝘌𝘓𝘚</summary>
 
1. `Fork` the Repository.
2. If already forked then `sync` fork repository.
3. Click on the green `Code` button and click `download as zip`.
4. `Upload` the script zip file to your `panel`.
5. `Unarchieve` the uploaded zip file.
6. Open the `unarchieved folder` and `move` all files to container by typing (`../`)
7. Now go to `console` and `start` bot.
8. Wait for `5-10 mins` to enter your number.
9. Enter your number when requested to get the pair code.
10. Enter pair code in link devices in whatsapp.
11. Deployment successful.
</details>
 

<details>
<summary>𝘔𝘈𝘕𝘜𝘈𝘓 𝘐𝘕𝘚𝘛𝘈𝘓𝘓𝘔𝘌𝘕𝘛𝘚</summary>
  
## `REQUIREMENTS`
* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* [FFmpeg](https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2020-12-08-13-03/ffmpeg-n4.3.1-26-gca55240b8c-win64-gpl-4.3.zip)
* [Libwebp](https://developers.google.com/speed/webp/download)
* Any text editor
  
## `CLONE REPO & INSTALLATION DEPENDENCIES`
```bash
git clone https://github.com/<your gitHub Username>/XPLOADER-BOT.git
cd XPLOADER-BOT
npm start
```

## `FOR SSH/UBUNTU/LINUX`
```bash
sudo apt-get update
sudo apt-get upgrade -y
sudo apt-get install -y bash
sudo apt-get install -y libwebp
sudo apt-get install -y git
sudo apt-get install -y nodejs
sudo apt-get install -y ffmpeg
sudo apt-get install -y wget
sudo apt-get install -y imagemagick
git clone https://github.com/<your-gitHub-Username>/XPLOADER-BOT
cd XPLOADER-BOT
npm install
npm start
```

## `FOR TERMUX`
```bash
apt update -y && apt upgrade -y && pkg update -y && pkg upgrade -y && pkg install bash -y && pkg install libwebp -y && pkg install git -y && pkg install nodejs -y && pkg install ffmpeg -y && pkg install wget -y && pkg install imagemagick -y && pkg install yarn && termux-setup-storage
cd /sdcard
cd bot folder name
yarn install
npm start
```

## `FOR 24/7 ACTIVATION PM2 (TERMUX)`
```bash
npm i -g pm2 && pm2 start index.js && pm2 save && pm2 logs
```

## `FOR 24/7 ACTIVATION RE-EXECUTION PM2 (TERMUX)`
```bash
npm i -g pm2 && pm2 start index.js -f && pm2 save && pm2 logs
```
</details>


</p>

##
* Need help? please create an <a href="https://github.com/Dark-Xploit/XPLOADER-BOT/issues">issue</a></p>

##
- Star ⭐ this repository if you like Xploader Bot.
- If any problem, then [`Whatsapp Me Here`](https://wa.me/254754783972)

##
<h2 align="center">  𝗣𝗢𝗟𝗜𝗧𝗘 𝗡𝗢𝗧𝗜𝗖𝗘!
</h2>

- *`XPLOADER BOT` is not affiliated with `WhatsApp Inc`.*
- *Misusing the bot may result in account banning.*
- *Use at your own risk.*

##
 [ XPLOADER WHATSAPP CHANNEL ](https://whatsapp.com/channel/0029VaaxfYH2ER6oOMkqFS3W)
 
## 
 [XPLOADER WHATSAPP GROUP ](https://chat.whatsapp.com/B6Hk3829WHYChdpqnuz7bL)

 
©𝐗𝐩𝐥𝐨𝐚𝐝𝐞𝐫𝐁𝐨𝐭
##
![MIT License](https://img.shields.io/badge/License-yellow.svg)
